const CACHE_NAME = 'mission-cache-v2';

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll([
        '/',                      // root (index.html)
        '/index.html',            // main HTML
        '/css/styles.css',        // CSS folder file
        '/icons/icon-192.png',    // icon image
        '/js/dashboard.js',       // JS files
        '/js/main.js',
        '/js/Study-tracker.js',
        '/js/Sunnah-tracker.js',
        '/js/top-student-mode.js',
        '/js/weekly-timetable.js',
        '/manifest.json',         // manifest file
        '/service-worker.js'      // service worker itself (optional to cache)
      ]);
    })
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cache => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request).catch(() => caches.match('/index.html'));
    })
  );
});
