const totalQuranPages = 604;
const totalJuz = 30;

function getDaysSinceStart(startDate) {
  const today = new Date();
  const start = new Date(startDate);
  const diff = Math.floor((today - start) / (1000 * 60 * 60 * 24));
  return diff + 1;
}

function loadSunnahTracker() {
  let saved = JSON.parse(localStorage.getItem('sunnah_progress')) || {};

  // Set or load start date
  let startDate = saved['startDate'] || new Date().toISOString().split('T')[0];
  if (!saved['startDate']) {
    saved['startDate'] = startDate;
    saveSunnahProgress({ startDate });
  }

  // Calculate tracking status
  let daysSinceStart = getDaysSinceStart(startDate);
  let expectedPages = Math.min(daysSinceStart, totalQuranPages);
  let actualPages = saved['pages'] || 0;
  let calculatedJuz = Math.floor((actualPages / totalQuranPages) * totalJuz);
  let status = actualPages === expectedPages ? '🟢 On Track' :
               actualPages > expectedPages ? '🟩 Ahead' : '🟠 Behind';

  // Build content
  let content = `
    <h2>🕌 Weekly Sunnah Tracker</h2>

    <div class="quran-progress">
      <h3>Qur'an Reading Progress (1 page/day)</h3>
      <p><strong>Started on:</strong> ${startDate}</p>
      <p><strong>Today is Day:</strong> ${daysSinceStart}</p>
      <p><strong>Expected Page:</strong> ${expectedPages}</p>
      <p><strong>Status:</strong> ${status}</p>

      <label>Pages Read:</label>
      <input id="quran-pages" type="number" min="0" max="${totalQuranPages}" value="${actualPages}" />
      <progress id="quran-pages-progress" max="${totalQuranPages}" value="${actualPages}"></progress>
      <p>${Math.round((actualPages / totalQuranPages) * 100)}% complete</p>

      <label>Juz Completed:</label>
      <input id="quran-juz" type="number" min="0" max="${totalJuz}" value="${calculatedJuz}" readonly />
      <progress id="quran-juz-progress" max="${totalJuz}" value="${calculatedJuz}"></progress>
      <p>${Math.round((calculatedJuz / totalJuz) * 100)}% complete</p>
  `;

  if (actualPages < expectedPages) {
    content += `<p style="color:red;"><strong>Don’t forget to read today’s page of the Qur’an 📖!</strong></p>`;
  } else if (actualPages === expectedPages) {
    content += `<p style="color:green;"><strong>Great job! You’re on track 💪</strong></p>`;
  } else {
    content += `<p style="color:blue;"><strong>MashaAllah! You’re ahead 🚀</strong></p>`;
  }

  content += `</div>`;

  // Add content to page
  document.getElementById('main-content').innerHTML = content;

  // Input handling
  const pagesInput = document.getElementById('quran-pages');
  const pagesProgress = document.getElementById('quran-pages-progress');
  const juzInput = document.getElementById('quran-juz');
  const juzProgress = document.getElementById('quran-juz-progress');

  pagesInput.addEventListener('input', () => {
    let pages = parseInt(pagesInput.value) || 0;
    if (pages < 0) pages = 0;
    if (pages > totalQuranPages) pages = totalQuranPages;

    let newJuz = Math.floor((pages / totalQuranPages) * totalJuz);

    pagesInput.value = pages;
    pagesProgress.value = pages;
    juzInput.value = newJuz;
    juzProgress.value = newJuz;

    saveSunnahProgress({ pages, juz: newJuz });
  });
}

function saveSunnahProgress(data) {
  let saved = JSON.parse(localStorage.getItem('sunnah_progress')) || {};
  saved = { ...saved, ...data };
  localStorage.setItem('sunnah_progress', JSON.stringify(saved));
}

// Expose function
window.loadSunnahTracker = loadSunnahTracker;
