// Study-tracker.js

// Load saved progress for a grade
function loadProgress(grade) {
  const saved = localStorage.getItem(`grade_${grade}_progress`);
  return saved ? JSON.parse(saved) : {};
}

// Save progress from inputs on current page
function saveStudyProgress(grade) {
  const subjectInputs = document.querySelectorAll('.subject-progress');
  const saved = {};

  subjectInputs.forEach(input => {
    const subject = input.dataset.subject;
    const value = parseFloat(input.value) || 0;
    saved[subject] = value;
  });

  localStorage.setItem(`grade_${grade}_progress`, JSON.stringify(saved));
  updateGradeSummary(grade);
}

// Create subject progress input block
function createSubject(name, maxPages, savedPages) {
  const progressPercent = maxPages > 0 ? Math.round((savedPages / maxPages) * 100) : 0;
  const completeClass = progressPercent === 100 ? 'complete' : '';
  return `
    <div class="subject ${completeClass}">
      <h3>${name}</h3>
      <input 
        class="subject-progress"
        type="number" 
        placeholder="Pages read" 
        min="0" 
        max="${maxPages}" 
        data-subject="${name}" 
        data-maxpages="${maxPages}" 
        value="${savedPages}" 
        aria-label="Pages read for ${name}"
      />
      <progress value="${savedPages}" max="${maxPages}" aria-label="Progress for ${name}"></progress>
      <p>${progressPercent}% complete</p>
    </div>
  `;
}

// Update a single subject's progress UI
function updateSubjectProgressUI(input) {
  let pages = parseInt(input.value) || 0;
  const maxPages = parseInt(input.getAttribute('data-maxpages'));

  if (pages > maxPages) {
    pages = maxPages;
    input.value = maxPages;
  } else if (pages < 0) {
    pages = 0;
    input.value = 0;
  }

  const progressPercent = Math.round((pages / maxPages) * 100);
  const container = input.closest('.subject');
  container.querySelector('progress').value = pages;
  container.querySelector('p').textContent = `${progressPercent}% complete`;

  if (progressPercent === 100) {
    container.classList.add('complete');
  } else {
    container.classList.remove('complete');
  }
}

// Load and display study section for a grade
function loadStudySection(grade) {
  const subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English'];
  let content = `<h2>📘 Grade ${grade} Study Tracker</h2><div class="subjects-container">`;

  if (!window.maxPagesByGrade || !window.maxPagesByGrade[grade]) {
    document.getElementById('main-content').innerHTML = `<p>Error: maxPagesByGrade data missing for Grade ${grade}.</p>`;
    return;
  }

  const savedProgress = loadProgress(grade);

  subjects.forEach(subject => {
    const maxPages = window.maxPagesByGrade[grade][subject] || 0;
    const savedPages = savedProgress[subject] || 0;
    content += createSubject(subject, maxPages, savedPages);
  });

  content += `</div>`;
  document.getElementById('main-content').innerHTML = content;

  // Add event listeners for inputs
  document.querySelectorAll('.subject-progress').forEach(input => {
    updateSubjectProgressUI(input); // Initial UI update

    input.addEventListener('input', function () {
      updateSubjectProgressUI(this);
      saveStudyProgress(grade);
    });
  });

  updateGradeSummary(grade);
}

// Overall progress bar for current grade
function updateGradeSummary(grade) {
  const subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English'];

  const saved = loadProgress(grade);
  let totalPercent = 0;
  let subjectCount = 0;

  if (!window.maxPagesByGrade || !window.maxPagesByGrade[grade]) return;

  subjects.forEach(subject => {
    const pagesRead = saved[subject] || 0;
    const maxPages = window.maxPagesByGrade[grade][subject] || 0;

    if (maxPages > 0) {
      const percent = (pagesRead / maxPages) * 100;
      totalPercent += percent;
      subjectCount++;
    }
  });

  const average = subjectCount > 0 ? Math.round(totalPercent / subjectCount) : 0;

  const progressContainer = document.getElementById('grade-progress-bar');
  if (progressContainer) {
    progressContainer.innerHTML = `
      <label>📘 Overall Progress for Grade ${grade}: ${average}%</label>
      <progress value="${average}" max="100"></progress>
    `;
  }
}

// Expose functions globally
window.loadStudySection = loadStudySection;
window.saveStudyProgress = saveStudyProgress;
window.updateGradeSummary = updateGradeSummary;
