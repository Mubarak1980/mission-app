// dashboard.js

function loadDashboard() {
  currentSection = 'dashboard';
  updateNavButtons();

  // Hide grade navigation on dashboard
  if (nav) nav.style.display = 'none';

  const subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English'];
  const grades = [9, 10, 11, 12];

  // Calculate average progress per subject across all grades
  let dashboardContent = '<h2>📊 Dashboard: Overall Subject Progress</h2><div class="dashboard-container">';

  subjects.forEach(subject => {
    let totalPercent = 0;
    let count = 0;

    grades.forEach(grade => {
      const saved = loadProgress(grade);
      const pagesRead = saved[subject] || 0;
      const maxPages = maxPagesByGrade[grade][subject];

      if (maxPages > 0) {
        const percent = (pagesRead / maxPages) * 100;
        totalPercent += percent;
        count++;
      }
    });

    const avgPercent = count > 0 ? Math.round(totalPercent / count) : 0;

    dashboardContent += `
      <div class="dashboard-subject">
        <h3>${subject}</h3>
        <progress value="${avgPercent}" max="100"></progress>
        <p>${avgPercent}% progress in ${subject} (Grades 9–12)</p>
      </div>
    `;
  });

  dashboardContent += '</div>';

  document.getElementById('main-content').innerHTML = dashboardContent;

  // Clear grade progress bar on dashboard
  const progressContainer = document.getElementById('grade-progress-bar');
  if (progressContainer) progressContainer.innerHTML = '';
}

// Expose globally for HTML button onclick
window.loadDashboard = loadDashboard;
