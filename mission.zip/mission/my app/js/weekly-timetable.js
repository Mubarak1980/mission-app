(() => {
  const grades = ['9', '10', '11', '12'];
  const currentGrade = '11'; // Highlight this grade

  const gradeDetails = {
    '12': [
      { subject: 'Mathematics', pages: 416, units: 3, days: 14 },
      { subject: 'Physics', pages: 177, units: 5, days: 6 },
      { subject: 'Chemistry', pages: 287, units: 5, days: 10 },
      { subject: 'Biology', pages: 354, units: 6, days: 12 },
      { subject: 'English', pages: 263, units: 10, days: 9 },
    ],
    '11': [
      { subject: 'Mathematics', pages: 479, units: 8, days: 16 },
      { subject: 'Physics', pages: 329, units: 7, days: 10 },
      { subject: 'Chemistry', pages: 330, units: 6, days: 11 },
      { subject: 'Biology', pages: 284, units: 6, days: 10 },
      { subject: 'English', pages: 283, units: 10, days: 10 },
    ],
    '10': [
      { subject: 'Mathematics', pages: 358, units: 7, days: 13 },
      { subject: 'Physics', pages: 249, units: 6, days: 9 },
      { subject: 'Chemistry', pages: 298, units: 6, days: 10 },
      { subject: 'Biology', pages: 174, units: 6, days: 6 },
      { subject: 'English', pages: 316, units: 10, days: 11 },
    ],
    '9': [
      { subject: 'Mathematics', pages: 363, units: 9, days: 12 },
      { subject: 'Physics', pages: 174, units: 7, days: 6 },
      { subject: 'Chemistry', pages: 164, units: 5, days: 6 },
      { subject: 'Biology', pages: 175, units: 6, days: 6 },
      { subject: 'English', pages: 223, units: 10, days: 8 },
    ],
  };

  function loadWeeklyTimetable() {
    const gradeNav = document.getElementById('grade-nav');
    if (gradeNav) gradeNav.style.display = 'none';

    const container = document.getElementById('main-content');
    if (!container) {
      console.error('Container with id "main-content" not found');
      return;
    }

    // 📅 Mission calendar calculation
    const startDate = new Date('2025-06-02'); // Change if your mission started earlier
    const today = new Date();
    const endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 194); // 195 days total (0-based)

    const daysPassed = Math.floor((today - startDate) / (1000 * 60 * 60 * 24));
    const daysLeft = 195 - daysPassed;

    const calendarSection = `
      <div class="calendar-section">
        <h3>📆 Study Mission Calendar</h3>
        <p><strong>Start Date:</strong> ${startDate.toDateString()}</p>
        <p><strong>End Date:</strong> ${endDate.toDateString()}</p>
        <p><strong>Today:</strong> ${today.toDateString()}</p>
        <p><strong>Days Left:</strong> ${daysLeft >= 0 ? daysLeft : '<span style="color:red">🚨 Mission Ended</span>'}</p>
      </div>
    `;

    let grandTotalDays = 0;
    let grandTotalPages = 0;
    
    const gradeHTML = grades.map(grade => {
      const subjects = gradeDetails[grade];
      if (!subjects) {
        console.warn(`No data for Grade ${grade}`);
        return `<div class="grade-box"><h3>Grade ${grade}</h3><p>No study plan available.</p></div>`;
      }

      const totalDays = subjects.reduce((sum, s) => sum + s.days, 0);
      const totalPages = subjects.reduce((sum, s) => sum + s.pages, 0);
      grandTotalDays += totalDays;
      grandTotalPages += totalPages;

      return `
        <div class="grade-box ${grade === currentGrade ? 'highlight' : ''}">
          <h3>Grade ${grade}</h3>
          <ul>
            ${subjects.map(({ subject, pages, units, days }) => `
              <li class="subject-item">
                <strong>${subject}</strong><br>
                Pages: ${pages}, Units: ${units}<br>
                Study Days: <span class="study-days">${days}</span>
              </li>
            `).join('')}
          </ul>
          <div class="total-days">
            Total Days: ${totalDays} &nbsp;&nbsp;|&nbsp;&nbsp; Total Pages: ${totalPages}
          </div>
        </div>
      `;
    }).join('');

    container.innerHTML = `
      <h2>🎯 195-Day Study Mission Plan (Grades 9 to 12)</h2>
      ${calendarSection}
      <div class="grades-container">
        ${gradeHTML}
      </div>
      <div class="grand-total-days">
        <h3>📅 Total Study Days: ${grandTotalDays}</h3>
        <h3>📚 Total Pages Across All Grades: ${grandTotalPages}</h3>
      </div>
    `;
  }

  window.loadWeeklyTimetable = loadWeeklyTimetable;
})();
