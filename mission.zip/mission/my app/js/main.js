// main.js

if (!window.maxPagesByGrade) {
  window.maxPagesByGrade = {
    9:  { Math: 300, Physics: 200, Chemistry: 180, Biology: 160, English: 250 },
    10: { Math: 280, Physics: 210, Chemistry: 190, Biology: 170, English: 240 },
    11: { Math: 320, Physics: 230, Chemistry: 200, Biology: 180, English: 260 },
    12: { Math: 350, Physics: 250, Chemistry: 220, Biology: 200, English: 270 },
  };
}

let currentGrade = 9;
let currentSection = 'study';  // Only study section now

// DOM references
let nav, prevBtn, nextBtn;

// Use global variable for maxPagesByGrade
const maxPagesByGrade = window.maxPagesByGrade;

function updateNavButtons() {
  if (!nav || !prevBtn || !nextBtn) {
    console.error('Navigation buttons not found in DOM.');
    return;
  }

  nav.style.display = 'flex';
  prevBtn.style.display = 'inline-block';
  nextBtn.style.display = 'inline-block';

  prevBtn.disabled = currentGrade === 9;
  nextBtn.disabled = currentGrade === 12;
}

// Save subject progress of the current grade
function saveProgress(grade) {
  const subjectInputs = document.querySelectorAll('.subject-progress');
  const saved = {};

  subjectInputs.forEach(input => {
    const subject = input.dataset.subject;
    const value = parseFloat(input.value) || 0;
    saved[subject] = value;
  });

  localStorage.setItem(`grade_${grade}_progress`, JSON.stringify(saved));
  updateGradeSummary(); // Update overall progress bar
}

// Load saved progress for a grade
function loadProgress(grade) {
  const saved = localStorage.getItem(`grade_${grade}_progress`);
  return saved ? JSON.parse(saved) : {};
}

// Create HTML for a subject's progress input and bar
function createSubject(name, maxPages, savedPages) {
  const progressPercent = maxPages > 0 ? Math.round((savedPages / maxPages) * 100) : 0;
  return `
    <div class="subject">
      <h3>${name}</h3>
      <input 
        class="subject-progress"
        type="number" 
        placeholder="Pages read" 
        min="0" 
        max="${maxPages}" 
        data-subject="${name}" 
        data-maxpages="${maxPages}"
        value="${savedPages}"
      />
      <progress value="${savedPages}" max="${maxPages}"></progress>
      <p>${progressPercent}% complete</p>
    </div>
  `;
}

function loadStudySection(grade) {
  const subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English'];
  let content = `<h2>📘 Grade ${grade} Study Tracker</h2><div class="subjects-container">`;

  const savedProgress = loadProgress(grade);

  subjects.forEach(subject => {
    const maxPages = maxPagesByGrade[grade][subject];
    const savedPages = savedProgress[subject] || 0;
    content += createSubject(subject, maxPages, savedPages);
  });

  content += `</div>`;

  document.getElementById('main-content').innerHTML = content;

  // Add event listeners for inputs
  document.querySelectorAll('.subject-progress').forEach(input => {
    input.addEventListener('input', function () {
      let pages = parseInt(this.value) || 0;
      const maxPages = parseInt(this.getAttribute('data-maxpages'));

      if (pages > maxPages) {
        pages = maxPages;
        this.value = maxPages;
      } else if (pages < 0) {
        pages = 0;
        this.value = 0;
      }

      const progressPercent = Math.round((pages / maxPages) * 100);
      const container = this.closest('.subject');
      container.querySelector('progress').value = pages;
      container.querySelector('progress').max = maxPages;
      container.querySelector('p').textContent = `${progressPercent}% complete`;

      saveProgress(currentGrade);
    });

    // Initialize progress bar and percentage on load
    const pages = parseInt(input.value) || 0;
    const maxPages = parseInt(input.getAttribute('data-maxpages'));
    const progressPercent = Math.round((pages / maxPages) * 100);
    const container = input.closest('.subject');
    container.querySelector('progress').value = pages;
    container.querySelector('progress').max = maxPages;
    container.querySelector('p').textContent = `${progressPercent}% complete`;
  });
}

// This function shows a single progress bar for the current grade only
function updateGradeSummary() {
  const grade = currentGrade;
  const subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English'];

  const saved = loadProgress(grade);
  let totalPercent = 0;
  let subjectCount = 0;

  subjects.forEach(subject => {
    const pagesRead = saved[subject] || 0;
    const maxPages = maxPagesByGrade[grade][subject];

    if (maxPages > 0) {
      const percent = (pagesRead / maxPages) * 100;
      totalPercent += percent;
      subjectCount++;
    }
  });

  const average = subjectCount > 0 ? Math.round(totalPercent / subjectCount) : 0;

  const progressContainer = document.getElementById('grade-progress-bar');
  if (progressContainer) {
    progressContainer.innerHTML = `
      <label>📘 Overall Progress for Grade ${grade}: ${average}%</label>
      <progress value="${average}" max="100"></progress>
    `;
  }
}

function nextGrade() {
  if (currentGrade < 12) {
    saveProgress(currentGrade);
    currentGrade++;
    loadSection('study', currentGrade);
  } else {
    saveProgress(currentGrade);
    document.getElementById('main-content').innerHTML = `<h2>🎉 You’ve completed all grades!</h2>`;
    const progressContainer = document.getElementById('grade-progress-bar');
    if (progressContainer) progressContainer.innerHTML = '';
  }
}

function previousGrade() {
  if (currentGrade > 9) {
    saveProgress(currentGrade);
    currentGrade--;
    loadSection('study', currentGrade);
  }
}

function loadSection(type, grade) {
  currentSection = type;
  updateNavButtons();

  if (type === 'study') {
    loadStudySection(grade);
    updateGradeSummary();
  }
}

// When DOM is ready
window.onload = () => {
  nav = document.getElementById('grade-nav');
  prevBtn = document.getElementById('prev-btn');
  nextBtn = document.getElementById('next-btn');

  loadSection('study', currentGrade);
};

// Expose functions to global scope for HTML button access
window.nextGrade = nextGrade;
window.previousGrade = previousGrade;
window.loadSection = loadSection;

// Service Worker registration (optional)
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('service-worker.js')
    .then(reg => console.log('✅ Service Worker registered:', reg.scope))
    .catch(err => console.error('❌ Service Worker registration failed:', err));
}
